### Code table of [Singapore map](../../maps/singapore.js)

|Code|Name|
|---|---|
|SG-CS|Central Singapore|
|SG-NE|North East|
|SG-NW|North West|
|SG-SE|South East|
|SG-SW|South West|
