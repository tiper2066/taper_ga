### Code table of [China map](../../maps/china.js)

|Code|Name|
|---|---|
|CN-AH|Anhui|
|CN-BJ|Beijing|
|CN-CQ|Chongqing|
|CN-FJ|Fujian|
|CN-GD|Guangdong|
|CN-GA|Gansu|
|CN-GZ|Guangxi Zhuang|
|CN-GH|Guizhou|
|CN-HN|Hainan|
|CN-HB|Hebei|
|CN-HE|Henan|
|CN-HK|Hong Kong|
|CN-HL|Heilongjiang|
|CN-HN|Hunan|
|CN-HU|Hubei|
|CN-JL|Jilin|
|CN-JS|Jiangsu|
|CN-JX|Jiangxi|
|CN-LN|Liaoning|
|CN-MC|Macau|
|CN-NM|Nei Mongol|
|CN-NH|Ningxia Hui|
|CN-QH|Quinghai|
|CN-SA|Shaanxi|
|CN-SH|Sichuan|
|CN-SD|Shandong|
|CN-SI|Shanghai|
|CN-SX|Shanxi|
|CN-TJ|Tianjin|
|CN-TW|Taiwan|
|CN-XY|Xinjiang Uygur|
|CN-TB|Xizang (Tibet)|
|CN-YN|Yunnan|
|CN-ZJ|Zhejiang|
