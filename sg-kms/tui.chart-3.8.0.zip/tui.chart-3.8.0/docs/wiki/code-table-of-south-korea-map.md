### Code table of [South Korea map](../../maps/south-korea.js)

|Code|Name|
|---|---|
|KR-SU|Seoul|
|KR-BS|Busan|
|KR-DG|Daegu|
|KR-IC|Incheon|
|KR-GJ|Gwangju|
|KR-DJ|Daejeon|
|KR-US|Ulsan|
|KR-GG|Gyeonggi|
|KR-GW|Gangwon|
|KR-NC|North Chungcheong|
|KR-SC|South Chungcheong|
|KR-NJ|North Jeolla|
|KR-SJ|South Jeolla|
|KR-NG|North Gyeongsang|
|KR-SG|South Gyeongsang|
|KR-JJ|Jeju|
|KR-SE|Sejong|
