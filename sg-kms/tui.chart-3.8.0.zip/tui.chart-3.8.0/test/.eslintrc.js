module.exports = {
    'rules': {
        'max-nested-callbacks': 'off',
        'object-property-newline': 'off'    
    }
};
